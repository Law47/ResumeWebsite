package main.distle;

import java.lang.annotation.Repeatable;
import java.util.*;

public class EditDistanceUtils {
    
    /**
     * Returns the completed Edit Distance memoization structure, a 2D array
     * of ints representing the number of string manipulations required to minimally
     * turn each subproblem's string into the other.
     * 
     * @param s0 String to transform into other
     * @param s1 Target of transformation
     * @return Completed Memoization structure for editDistance(s0, s1)
     */
    public static int[][] getEditDistTable (String s0, String s1) {
        int[][] table = new int[s0.length()+1][s1.length()+1];
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                if (i == 0) {
                    table[i][j] = j;
                    continue;
                }
                if (j == 0) {
                    table[i][j] = i;
                    continue;
                }
                int deletion = Integer.MAX_VALUE;
                int insertion = Integer.MAX_VALUE;
                int replacement = Integer.MAX_VALUE;
                int transposition = Integer.MAX_VALUE;        
                if (j >= 1) {
                    insertion = table[i][j-1] + 1;
                }
                if (i >= 1) {
                    deletion = table[i-1][j] + 1;
                }
                if (i >= 1 && j>= 1) {
                    replacement = table[i-1][j-1] + (s0.charAt(i-1) != s1.charAt(j-1) ? 1 : 0);
                }
                if (i >= 2 && j >= 2 && s0.charAt(i-1) == s1.charAt(j-2) && s1.charAt(j-1) == s0.charAt(i-2)) {
                    transposition = table[i-2][j-2] + 1;
                }
                table[i][j] = Math.min(Math.min(deletion, insertion), Math.min(replacement, transposition));
            }
        }
        return table;
    }
    
    /**
     * Returns one possible sequence of transformations that turns String s0
     * into s1. The list is in top-down order (i.e., starting from the largest
     * subproblem in the memoization structure) and consists of Strings representing
     * the String manipulations of:
     * <ol>
     *   <li>"R" = Replacement</li>
     *   <li>"T" = Transposition</li>
     *   <li>"I" = Insertion</li>
     *   <li>"D" = Deletion</li>
     * </ol>
     * In case of multiple minimal edit distance sequences, returns a list with
     * ties in manipulations broken by the order listed above (i.e., replacements
     * preferred over transpositions, which in turn are preferred over insertions, etc.)
     * @param s0 String transforming into other
     * @param s1 Target of transformation
     * @param table Precomputed memoization structure for edit distance between s0, s1
     * @return List that represents a top-down sequence of manipulations required to
     * turn s0 into s1, e.g., ["R", "R", "T", "I"] would be two replacements followed
     * by a transposition, then insertion.
     */
    public static List<String> getTransformationList (String s0, String s1, int[][] table) {
        List<String> result = new ArrayList<String>();
        int r = table.length - 1;
        int c = table[0].length - 1;
        while (table[r][c] != 0) {
            if (r >= 1 && c >= 1 && s0.charAt(r-1) == s1.charAt(c-1)) {
                r -= 1;
                c -= 1;
                continue;
            }
            if (r >= 1 && c >= 1 && table[r-1][c-1] == table[r][c] - 1) {
                result.add("R");
                r -= 1;
                c -= 1;
                continue;
            }
            if (r >= 2 && c >= 2 && s0.charAt(r-1) == s1.charAt(c-2) && s1.charAt(c-1) == s0.charAt(r-2)) {
                result.add("T");         
                r -= 2;
                c -= 2;
                continue;
            }
            if (c >= 1 && table[r][c-1] == table[r][c] - 1) {
                result.add("I");
                c -= 1;
                continue;
            }
            if (r >= 1 && table[r-1][c] == table[r][c] - 1) {
                result.add("D");
                r -= 1;
                continue;
            }
        }
        return result;
    }
    
    /**
     * Returns the edit distance between the two given strings: an int
     * representing the number of String manipulations (Insertions, Deletions,
     * Replacements, and Transpositions) minimally required to turn one into
     * the other.
     * 
     * @param s0 String to transform into other
     * @param s1 Target of transformation
     * @return The minimal number of manipulations required to turn s0 into s1
     */
    public static int editDistance (String s0, String s1) {
        if (s0.equals(s1)) { return 0; }
        return getEditDistTable(s0, s1)[s0.length()][s1.length()];
    }
    
    /**
     * See {@link #getTransformationList(String s0, String s1, int[][] table)}.
     */
    public static List<String> getTransformationList (String s0, String s1) {
        return getTransformationList(s0, s1, getEditDistTable(s0, s1));
    }

}

// ===================================================
// >>> [TN] Summary
// Very good job! Both the Utils and the Player work excellently
// The code is clean and variable names are well chosen
// Keep up the good work!
// ---------------------------------------------------
// >>> [TN] Style Checklist
// [X] = Good, [~] = Mixed bag, [ ] = Needs improvement
//
// [X] Variables and helper methods named and used well
// [X] Proper and consistent indentation and spacing
// [X] Proper JavaDocs provided for ALL methods
// [X] Logic is adequately simplified
// [X] Code repetition is kept to a minimum
// ---------------------------------------------------
// Correctness:         100 / 100
// -> EditDistUtils:    20 / 20  (-2 / missed test)
// -> DistlePlayer:     278 / 265 (-0.5 / below threshold; max -25)
// Style Penalty:       -0
// Total:               100 / 100
// ===================================================