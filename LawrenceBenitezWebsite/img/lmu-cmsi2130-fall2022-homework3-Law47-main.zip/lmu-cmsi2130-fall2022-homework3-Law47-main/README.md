# CMSI 2130 - Homework 3
Wordle was the appetizer... time for the main course.

Lawrence Benitez